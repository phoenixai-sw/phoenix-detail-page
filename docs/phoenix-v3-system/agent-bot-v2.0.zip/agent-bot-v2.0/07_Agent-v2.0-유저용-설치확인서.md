# Agent v2.0 유저용 설치확인서

## 1. 목적

Phoenix Agent v2.0 설치 후 각 봇이 정상 작동하고, agent web 컨트롤 준비가 되었는지 확인한다.

## 2. 기본 봇 확인

각 봇에게 `/start`를 보낸다.

확인 대상:

1. Genesis Bot
2. Design Bot
3. Writer Bot
4. Video Bot
5. Power Bot

성공 기준:

```text
각 봇이 자기 이름과 역할을 말한다.
```

## 3. Genesis Bot 확인

```text
이 제품으로 상세페이지, 제품컷, 랜딩페이지, PPT, SNS 카피까지 만드는 작업을 나눠줘.
```

성공 기준:

1. Genesis Bot이 task를 나눈다.
2. phoenix command 등록을 언급한다.
3. Design Bot, Writer Bot 역할을 구분한다.
4. 실행 전 승인 여부를 묻는다.

## 4. Design Bot 확인

```text
phoenix images로 제품 썸네일 생성 준비 상태를 확인해줘.
```

성공 기준:

1. Design Bot이 phoenix images 역할을 안다.
2. 제품명, 브랜드명, 이미지 용도, 비율을 질문한다.
3. 다운로드 형식을 설명한다.

## 5. Writer Bot 확인

```text
phoenix books로 강의교안 생성 준비 상태를 확인해줘.
```

성공 기준:

1. Writer Bot이 phoenix books 역할을 안다.
2. 주제, 대상, 분량, 톤을 질문한다.
3. DOCX/PDF 결과물을 설명한다.

## 6. Video Bot 확인

```text
phoenix videos로 15초 숏폼 생성 준비 상태를 확인해줘.
```

성공 기준:

1. Video Bot이 영상 길이, 장면 수, 스타일을 질문한다.
2. 영상 생성은 비용/시간이 들 수 있음을 안내한다.

## 7. Power Bot 확인

```text
phoenix marketing으로 고객사 AI 검색 현황 분석 준비 상태를 확인해줘.
```

성공 기준:

1. Power Bot이 고객사, 플랫폼, 키워드를 질문한다.
2. 대시보드/상담/보고서 결과물을 설명한다.

추가 확인:

```text
phoenix tax와 phoenix dental 상담형 웹의 주의사항을 설명해줘.
```

성공 기준:

1. Power Bot이 세무/의료 고위험 정보 주의사항을 설명한다.
2. 전문가 확인 필요성을 안내한다.

## 8. 실패 시 확인

1. Telegram pairing이 완료되었는가?
2. PM2에서 봇이 online인가?
3. OpenClaw gateway health가 정상인가?
4. 웹사이트 주소가 맞는가?
5. API 키 또는 로그인 상태가 준비되었는가?
